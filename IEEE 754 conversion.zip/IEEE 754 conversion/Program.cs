﻿using System;
using System.Buffers.Binary;

int x,y;
char operation;

Console.WriteLine("Please type in your first integer: ");
x = Int32.Parse(Console.ReadLine());
Console.WriteLine("Now type in your second integer: ");
y = Int32.Parse(Console.ReadLine());
Console.WriteLine("Type in the operator(+,-,*): ");
operation = Convert.ToChar(Console.ReadLine());

NumberChecker(MathOperation(x, y, operation));
Console.WriteLine("Decimal to Hex for x: " + DecToHex(x));
Console.WriteLine("Decimal to Hex for y: " + DecToHex(y));
Console.WriteLine("Decimal to Binary for x: " + DecToBinary(x));
Console.WriteLine("Decimal to Binary for y: " + DecToBinary(y));
Console.WriteLine("Binary to Decimal for x: " + BinaryToDec(x));
Console.WriteLine("Binary to Decimal for y: " + BinaryToDec(y));
Console.WriteLine("Hex to Decimal for x: " + HexToDec(DecToHex(x)));
Console.WriteLine("Hex to Decimal for y: " + HexToDec(DecToHex(y)));
Console.WriteLine("Decimal to Sign Exponent Mantissa for x: " + BinaryToSEM(DecToBinary(x)));
Console.WriteLine("Decimal to Sign Exponent Mantissa for y: " + BinaryToSEM(DecToBinary(y)));
Console.WriteLine("Sign Exponent Mantissa to Decimal for x: " + SEMToBinary(BinaryToSEM(DecToBinary(x))));
Console.WriteLine("Sign Exponent Mantissa to Decimal for y: " + SEMToBinary(BinaryToSEM(DecToBinary(y))));


Console.WriteLine("Operation result: " + MathOperation(x, y, operation));

//Math Operations
static float MathOperation(float x, float y, char operation)
{
    if (operation == '+')
        return (x + y);
    else if (operation == '-')
        return (x - y);
    else if (operation == '*')
        return (x * y);
    else
        return 0;
}

static string NumberChecker(float input)
{
    return "";
}

//Convert Binary to Decimal
static int BinaryToDec(int z)
{
    int decimalValue = 0;
    int base1 = 1;

    while(z > 0)
    {
        int remainder = z % 10;
        z = z / 10;
        decimalValue += remainder * base1;
        base1 = base1 * 2;
    }

    return decimalValue;
}

//Convert Hexadecimal to Decimal
static int HexToDec(string z)
{
    z = z.ToUpper();

    int zLength = z.Length;
    double dec = 0;

    for(int i = 0; i < zLength; i++)
    {
        byte b = (byte)z[i];

        if (b >= 48 && b <= 57)
            b -= 48;
        else if (b >= 65 && b <= 70)
            b -= 55;

        dec += b * Math.Pow(16,((zLength - i) - 1));
    }

    return (int)dec;
}
//Convert to Binary to Sign Exponent Mantissa
static float BinaryToSEM(string z)
{
    int sem = Convert.ToInt32(z, 2);
    return BitConverter.ToSingle(BitConverter.GetBytes(sem), 0);
}

//Convert to Sign Exponent Mantissa to Binary
static string SEMToBinary(float z)
{
    const int bitCount = sizeof(float) * 8;
    int bin = System.BitConverter.ToInt32(BitConverter.GetBytes(z), 0);
    return Convert.ToString(bin, 2).PadLeft(bitCount, '0');
}

//convert to hexadecimal
static string DecToHex(float z)
{
    var hex = BitConverter.SingleToInt32Bits(z).ToString();
    return hex;
}

//convert to binary
static string DecToBinary(float z)
{
    
    string str = "";
    string binary = "";

    while (z >= 1)
    {
        str = str + (z % 2).ToString();
        z = z / 2;
    }
    
    for (int i = str.Length - 1; i >= 0; i--)
    {
        binary = binary + str[i];
    }

    return binary;
}